from rdflib import Namespace
RETE_NS = Namespace("http://metacognition.info/ontologies/ReteVocabulary.owl#")